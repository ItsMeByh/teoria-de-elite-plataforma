# Teoria de Elite
Plataforma gratuita de teoria musical (HTML, CSS e JS puros; progresso em LocalStorage). Criador: Gabriel Gracioli Cacho.

## Estrutura
- `index.html`, `curso.html`, `historia.html`, `materiais.html`, `avaliacoes.html`, `progresso.html`, `ajuda.html`, `sobre.html`
- `aula.html?n=1..50` — modelo único que gera qualquer aula a partir de `js/data.js`
- `css/style.css` · `js/` (`data`, `progress`, `quiz`, `lessons`, `app`) · `assets/`

## Rodar localmente
Abra `index.html` no navegador. Não precisa de servidor, Node ou npm.

## Publicar no GitHub Pages
Suba a pasta para um repositório, depois Settings → Pages → branch `main`, pasta `/ (root)`. Todos os caminhos são relativos.

## Onde editar
- Aulas: `AULAS` em `js/data.js` (título, introdução, 4 conceitos, exemplo, desafio). O quiz é gerado dos conceitos.
- XP e estrelas: `CONFIG` · Níveis: `NIVEIS` · Conquistas: `CONQUISTAS` · Etapas: `ETAPAS`
- Dados do aluno: LocalStorage, chave `tde_v1` (perfil editável no Início).
- Nova aula: adicione um `L(...)` em `AULAS` e ajuste o intervalo em `ETAPAS`.
