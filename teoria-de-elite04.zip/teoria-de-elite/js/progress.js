const KEY="tde_v1";
const DEFAULT=()=>({profile:null,xp:0,stars:0,done:[],streak:0,last:null,ach:[],evals:[],mats:[],xpEval:[]});
let state=loadProgress();
function loadProgress(){try{return Object.assign(DEFAULT(),JSON.parse(localStorage.getItem(KEY))||{})}catch(e){return DEFAULT()}}
function saveProgress(){try{localStorage.setItem(KEY,JSON.stringify(state))}catch(e){}}
const fmt=d=>d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0");
const today=()=>fmt(new Date());
function yesterday(){const d=new Date();d.setDate(d.getDate()-1);return fmt(d)}
function addXP(n){state.xp+=n;saveProgress()}
function calculateLevel(xp=state.xp){let i=0;NIVEIS.forEach((l,k)=>{if(xp>=l[0])i=k});const nx=NIVEIS[i+1];return{idx:i,nome:NIVEIS[i][1],next:nx?nx[0]:null,falta:nx?nx[0]-xp:0,pct:nx?Math.round((xp-NIVEIS[i][0])/(nx[0]-NIVEIS[i][0])*100):100}}
function isUnlocked(n){return n===1||state.done.includes(n-1)}
function unlockNextLesson(){for(let n=1;n<=AULAS.length;n++)if(!state.done.includes(n))return n;return null}
function updateStreak(){const t=today();if(state.last===t)return;state.streak=state.last===yesterday()?state.streak+1:1;state.last=t}
function checkAchievements(){const novas=[];CONQUISTAS.forEach(c=>{if(!state.ach.includes(c.id)&&c.t(state)){state.ach.push(c.id);novas.push(c)}});return novas}
function completeLesson(n){if(state.done.includes(n)||!isUnlocked(n))return null;state.done.push(n);state.xp+=CONFIG.xpAula;state.stars+=CONFIG.estrelaAula;updateStreak();const novas=checkAchievements();saveProgress();return{xp:CONFIG.xpAula,stars:CONFIG.estrelaAula,novas}}
function recordEval(id,titulo,score,total,xpBase){const pct=Math.round(score/total*100);const first=!state.xpEval.includes(id);let xp=0,st=0;if(first){xp=xpBase;state.xpEval.push(id)}if(pct===100&&!state.evals.some(e=>e.id===id&&e.pct===100))st=CONFIG.estrelasPerfeito;state.xp+=xp;state.stars+=st;updateStreak();state.evals.push({id,titulo,score,total,pct,data:today()});const novas=checkAchievements();saveProgress();return{xp,st,pct,novas}}
function updateProgress(){const t=AULAS.length;return{done:state.done.length,total:t,pct:Math.round(state.done.length/t*100)}}
function etapaProgress(e){let d=0;for(let n=e.de;n<=e.ate;n++)if(state.done.includes(n))d++;return{d,t:e.ate-e.de+1}}
