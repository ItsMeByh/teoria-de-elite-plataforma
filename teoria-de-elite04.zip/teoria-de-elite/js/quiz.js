const shuffle=a=>{a=a.slice();for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a};
const factsOf=n=>AULAS[n-1].f.map(x=>({t:x[0],d:x[1]}));
const allFacts=()=>AULAS.flatMap((a,i)=>factsOf(i+1));
function makeQuestion(f,rev){const pool=allFacts().filter(x=>x.d!==f.d&&x.t!==f.t);
 if(!rev)return{q:"O que é/significa “"+f.t+"”?",o:shuffle([f.d,...shuffle(pool).slice(0,3).map(x=>x.d)]),c:f.d,e:f.t+": "+f.d};
 return{q:"Qual conceito corresponde a: “"+f.d+"”?",o:shuffle([f.t,...shuffle(pool).slice(0,3).map(x=>x.t)]),c:f.t,e:f.t+": "+f.d}}
function lessonQuiz(n){const f=shuffle(factsOf(n));const qs=f.map(x=>makeQuestion(x,false));qs.push(makeQuestion(f[0],true));return qs}
function stageQuiz(e,cnt=10){const f=[];for(let n=e.de;n<=e.ate;n++)f.push(...factsOf(n));return shuffle(f).slice(0,cnt).map((x,i)=>makeQuestion(x,i%3===2))}
function generalQuiz(cnt=20){return shuffle(allFacts()).slice(0,cnt).map((x,i)=>makeQuestion(x,i%3===2))}
function classify(p){return p===100?"Excelente":p>=80?"Muito bom":p>=60?"Continue praticando":"Revise a aula"}
function runQuiz(el,qs,onEnd){let i=0,ok=0;const L="ABCD";
 function show(){const q=qs[i];el.innerHTML='<div class="q-head">Questão '+(i+1)+' de '+qs.length+'</div><div class="bar"><span style="width:'+(i/qs.length*100)+'%"></span></div><h3 class="q-text"></h3><div class="opts"></div><div class="fb" aria-live="polite"></div>';
  el.querySelector(".q-text").textContent=q.q;const box=el.querySelector(".opts");
  q.o.forEach((t,k)=>{const b=document.createElement("button");b.className="opt";b.type="button";b.dataset.v=t;b.innerHTML="<b>"+L[k]+")</b> <span></span>";b.lastChild.textContent=t;
   b.onclick=()=>{box.querySelectorAll("button").forEach(x=>{x.disabled=true;if(x.dataset.v===q.c)x.classList.add("right")});
    const hit=t===q.c;if(hit)ok++;else b.classList.add("wrong");
    const fb=el.querySelector(".fb");fb.innerHTML="<p class='"+(hit?"ok":"no")+"'>"+(hit?"Acertou!":"Errou.")+"</p><p></p>";fb.children[1].textContent=q.e;
    const nb=document.createElement("button");nb.className="btn";nb.textContent=i===qs.length-1?"Ver resultado":"Próxima";nb.onclick=()=>{i++;i<qs.length?show():end()};fb.appendChild(nb);nb.focus()};
   box.appendChild(b)})}
 function end(){const p=Math.round(ok/qs.length*100);el.innerHTML='<div class="result"><h3>Você acertou '+ok+' de '+qs.length+'.</h3><p class="big">'+p+'% — '+classify(p)+'</p></div>';onEnd&&onEnd(ok,qs.length,p)}
 show()}
