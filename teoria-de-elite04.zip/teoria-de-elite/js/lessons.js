function staffSVG(clef,notes){const W=80+notes.length*44;let s='<svg viewBox="0 0 '+W+' 130" role="img" aria-label="Pentagrama" class="svg">';
 for(let i=0;i<5;i++)s+='<line x1="10" x2="'+(W-10)+'" y1="'+(90-i*12)+'" y2="'+(90-i*12)+'" stroke="currentColor"/>';
 if(clef)s+='<text x="14" y="'+(clef==="fa"?88:100)+'" font-size="'+(clef==="fa"?52:70)+'" fill="#d4af37">'+(clef==="fa"?"𝄢":"𝄞")+'</text>';
 notes.forEach((p,k)=>{const x=76+k*44,y=90-p*6;s+='<ellipse cx="'+x+'" cy="'+y+'" rx="8" ry="6" fill="currentColor"/><line x1="'+(x+8)+'" x2="'+(x+8)+'" y1="'+y+'" y2="'+(y-32)+'" stroke="currentColor" stroke-width="2"/>'});
 return s+'</svg>'}
function keyboardSVG(hi){hi=hi||[];const N=["C","D","E","F","G","A","B"];let s='<svg viewBox="0 0 350 120" class="svg" role="img" aria-label="Teclado">';
 for(let i=0;i<14;i++)s+='<rect x="'+(i*25)+'" y="0" width="25" height="115" fill="'+(hi.includes(i)?"#d4af37":"#f4f1ea")+'" stroke="#111"/>';
 for(let i=0;i<13;i++)if([0,1,3,4,5].includes(i%7))s+='<rect x="'+(i*25+17)+'" y="0" width="16" height="70" fill="#111"/>';
 for(let i=0;i<14;i++)s+='<text x="'+(i*25+12)+'" y="108" font-size="9" text-anchor="middle" fill="#111">'+N[i%7]+'</text>';return s+'</svg>'}
function figurasHTML(){return '<div class="figs">'+[["𝅝","Semibreve","4"],["𝅗𝅥","Mínima","2"],["♩","Semínima","1"],["♪","Colcheia","1/2"],["♬","Semicolcheia","1/4"]].map(f=>'<div class="fig"><span>'+f[0]+'</span><b>'+f[1]+'</b><small>'+f[2]+' tempo(s)</small></div>').join("")+'</div>'}
function visualFor(n){if(n===5)return staffSVG("",[]);if(n===6)return staffSVG("sol",[0,1,2,3,4,5,6,7,8]);if(n===7)return staffSVG("fa",[0,1,2,3,4,5,6,7,8]);if(n===8)return staffSVG("sol",[4,2,6,3,0]);
 if(n===9)return figurasHTML();if([4,29,30,33,36].includes(n))return keyboardSVG([0,2,4,5,7,9,11]);return '<div class="wave">'+Array.from({length:28},(_,i)=>'<i style="height:'+(20+Math.abs(Math.sin(i*.7+n))*70)+'%"></i>').join("")+'</div>'}
function renderLesson(root){const n=parseInt(new URLSearchParams(location.search).get("n"))||1;const a=AULAS[n-1];
 if(!a||!isUnlocked(n)){root.innerHTML='<section class="wrap"><h1>Aula bloqueada</h1><p>Conclua a aula anterior para liberar esta.</p><a class="btn" href="curso.html">Voltar à jornada</a></section>';return}
 const et=ETAPAS.find(e=>n>=e.de&&n<=e.ate),feita=state.done.includes(n);
 root.innerHTML='<article class="wrap lesson"><p class="eyebrow">Etapa '+et.n+' — '+et.nome+' · Aula '+String(n).padStart(2,"0")+'</p><h1></h1><p class="lead"></p>'+
 '<div class="card"><h2>Objetivo</h2><p id="ob"></p></div><div class="card"><h2>Explicação principal</h2><dl id="fx"></dl></div>'+
 '<div class="card"><h2>Elementos visuais</h2><div class="vis">'+visualFor(n)+'</div></div><div class="card"><h2>Exemplo prático</h2><p id="ex"></p></div>'+
 '<div class="card"><h2>Exercício interativo</h2><label class="chk"><input type="checkbox"> <span id="exr"></span></label></div>'+
 '<div class="card"><h2>Desafio</h2><label class="chk"><input type="checkbox"> <span id="dsf"></span></label></div>'+
 '<div class="card"><h2>Quiz</h2><div id="quiz"></div></div><div class="card"><h2>Resumo</h2><ul id="rs"></ul></div>'+
 '<div class="card reward"><p>Recompensa: <b>+'+CONFIG.xpAula+' XP</b> · <b>⭐ +'+CONFIG.estrelaAula+'</b></p><button class="btn gold" id="fim" disabled>'+(feita?"Aula já concluída":"Concluir aula")+'</button><p class="hint" id="hint">'+(feita?"":"Finalize o quiz para concluir.")+'</p></div>'+
 '<nav class="pager">'+(n>1?'<a class="btn ghost" href="aula.html?n='+(n-1)+'">← Anterior</a>':"<span></span>")+(n<AULAS.length&&feita?'<a class="btn ghost" href="aula.html?n='+(n+1)+'">Próxima →</a>':"")+'</nav></article>';
 root.querySelector("h1").textContent=a.t;root.querySelector(".lead").textContent=a.i;
 root.querySelector("#ob").textContent="Compreender: "+a.f.map(f=>f[0].toLowerCase()).join(", ")+".";
 const dl=root.querySelector("#fx");a.f.forEach(f=>{const dt=document.createElement("dt"),dd=document.createElement("dd");dt.textContent=f[0];dd.textContent=f[1];dl.append(dt,dd)});
 root.querySelector("#ex").textContent=a.e;root.querySelector("#exr").textContent="Fiz o exercício: "+a.e;root.querySelector("#dsf").textContent=a.d;
 const rs=root.querySelector("#rs");a.f.forEach(f=>{const li=document.createElement("li");li.textContent=f[0]+" — "+f[1];rs.appendChild(li)});
 const fim=root.querySelector("#fim");
 runQuiz(root.querySelector("#quiz"),lessonQuiz(n),(ok,t,p)=>{if(!feita){fim.disabled=false;root.querySelector("#hint").textContent="Quiz finalizado: "+p+"% — "+classify(p)+"."}});
 fim.onclick=()=>{const r=completeLesson(n);if(r)showComplete(n,r)}}
function showComplete(n,r){const o=document.createElement("div");o.className="overlay";const nxt=n<AULAS.length?'<a class="btn gold" href="aula.html?n='+(n+1)+'">PRÓXIMA AULA</a>':'<a class="btn gold" href="progresso.html">VER PROGRESSO</a>';
 o.innerHTML='<div class="modal"><p class="eyebrow">AULA CONCLUÍDA</p><h2>+'+r.xp+' XP</h2><p>⭐ +'+r.stars+' ESTRELA</p><p>Seu progresso aumentou para '+updateProgress().pct+'%.</p>'+(r.novas.length?'<p class="gold-t">Conquista: '+r.novas.map(c=>c.n).join(", ")+'</p>':"")+nxt+'</div>';document.body.appendChild(o)}
